create trigger TRG_USER
	before insert
	on T_USER
	for each row
begin
select SEQ_USER.nextval into:new.id from dual;
end;
